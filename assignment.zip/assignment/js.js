const User1={ 
	User:"Jake",
	passwd:"Jakespassword",
} /* Defines an object User1 */
Users=[User1] /* Defines a list of users using the object(s) defined above */